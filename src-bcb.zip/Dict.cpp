//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainForm.h"
#include "Dict.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TProlanfDict *ProlanfDict;
//---------------------------------------------------------------------------
__fastcall TProlanfDict::TProlanfDict(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
bool TProlanfDict::Save()
{
        if (HasName)
        {       Memo->Lines->SaveToFile(name);
                Memo->Modified=false;
                return false;
        } else return SaveAs();
}

bool TProlanfDict::SaveOne()
{
        if (Memo->Modified) return Save();
        return false;
}

bool TProlanfDict::AskSave()
{
        if (Memo->Modified)
        {       switch (Application->MessageBoxA((String("��������� ��������� � ����� \"")+name+"\"?").c_str(),
                        "ProLanF",MB_YESNOCANCEL | MB_ICONQUESTION))
                { case IDYES: return Save();
                  case IDCANCEL: return true;
                }
        }
        return false;
}

void TProlanfDict::Open(String& filename)
{
        Memo->Lines->LoadFromFile(filename);
        FileName=filename;
        name=ExtractFileName(filename);
        Caption=name;
        HasName=true;
}

bool TProlanfDict::SaveAs()
{
        ProlanfForm->SaveDialog->FileName=FileName;
        if (ProlanfForm->SaveDialog->Execute())
        {       Memo->Lines->SaveToFile(ProlanfForm->SaveDialog->FileName);
                FileName=ProlanfForm->SaveDialog->FileName;
                name=ExtractFileName(FileName);
                Caption=name;
                HasName=true;
                return false;
        }
        return true;
}

void __fastcall TProlanfDict::FormClose(TObject *Sender,
      TCloseAction &Action)
{
        if (AskSave()) Action=caNone; else
        {       Action=caFree;
                ProlanfForm->CloseDictExecute(this);
                ProlanfForm->DictSelected=false;
                ProlanfForm->SaveDict->Enabled=false;
                ProlanfForm->SaveDictAs->Enabled=false;
        }
}
//---------------------------------------------------------------------------

void __fastcall TProlanfDict::FormActivate(TObject *Sender)
{
        ProlanfForm->DictSelected=true;
        ProlanfForm->SaveDict->Enabled=true;
        ProlanfForm->SaveDictAs->Enabled=true;
}
//---------------------------------------------------------------------------

void __fastcall TProlanfDict::FormDeactivate(TObject *Sender)
{
        ProlanfForm->DictSelected=false;
        ProlanfForm->SaveDict->Enabled=false;
        ProlanfForm->SaveDictAs->Enabled=false;
}
//---------------------------------------------------------------------------


