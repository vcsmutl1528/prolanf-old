//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Message.h"
#include "MainForm.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMessageForm *MessageForm;
//---------------------------------------------------------------------------
__fastcall TMessageForm::TMessageForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TMessageForm::FormClose(TObject *Sender,
      TCloseAction &Action)
{
        ProlanfForm->ViewMessages->Checked=false;
        Action=caFree;
}
//---------------------------------------------------------------------------


void TMessageForm::UpdateMessages()
{
        ProlanfError **mlist=ProlanfForm->err->List();
        ListBox->Items->Clear();
        for (int i=0; i<ProlanfForm->err->Count(); i++)
                ListBox->Items->Add(*mlist[i]);
}

void __fastcall TMessageForm::FormCreate(TObject *Sender)
{
        UpdateMessages();
}
//---------------------------------------------------------------------------
void __fastcall TMessageForm::ListBoxDblClick(TObject *Sender)
{
        ProlanfError *perr;
        if (ListBox->ItemIndex!=-1 && ProlanfForm->err->List()[ListBox->ItemIndex]->dict!=NULL)
        {       perr=ProlanfForm->err->List()[ListBox->ItemIndex];
                perr->dict->Memo->SelStart=perr->start;
                perr->dict->Memo->SelLength=perr->lenght;
                perr->dict->FormActivate(Sender);
                perr->dict->BringToFront();
        }
}
//---------------------------------------------------------------------------

