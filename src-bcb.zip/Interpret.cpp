//---------------------------------------------------------------------------


#pragma hdrstop

#include "Interpret.h"
//DEBUG
#include "FuncForm.h"
#include "Console.h"
//---------------------------------------------------------------------------

#pragma package(smart_init)

bool ProlanfOpt::CompareKeywords(const String& a, const String& b)
{       if (CaseSensKeywords) return !AnsiCompareStr(a,b);
        else return !AnsiCompareText(a,b);
}

bool ProlanfOpt::CompareNames(const String& a, const String& b)
{       if (CaseSensNames) return !AnsiCompareStr(a,b);
        else return !AnsiCompareText(a,b);
}

bool ProlanfOpt::CompareStrings(const String& a, const String& b)
{       if (CaseSensStrings) return !AnsiCompareStr(a,b);
        else return !AnsiCompareText(a,b);
}

char ParsedString::OneCharLex[]={ '(', ')', ',', '=', '-', ';' };
LexemeType ParsedString::Correspond[]={ lexOpBr, lexClBr, lexComma, lexEqu, lexDash, lexSemic };

ParsedString::ParsedString() { list=new TList; }
ParsedString::~ParsedString()
{       Clear();
        delete list;
}

void ParsedString::Parse(char* text, ProlanfOpt& opt)
{
        int n=0, bn, i;
        char *c, sc;
        Clear();
        while(*text)
        {       for(i=0; i<6; i++) if (*text==OneCharLex[i]) break;
                if (i<6)
                {       list->Add(new Lexeme(Correspond[i],n,1));
                        text++; n++; continue;
                }
                switch(*text)
                { case '\"': if (!opt.AllowDoubleQuotes) goto itschar;
                        sc='\"'; goto beginconst;
                  case '\'': sc='\'';
                  beginconst: c=text; bn=n; text++; n++;
                        while(*text!=sc && *text) { text++; n++; }
                        list->Add(new Lexeme(lexStr, bn, n-bn+1, String(c+1, n-bn-1)));
                        if (!*text) text--; break;
                  case '/': while(*text!=10 && *text!=13 && *text) { text++; n++; }
                        if (!*text) text--; break;
                  itschar:
                  default: if (((unsigned char)*text)<33) break;
                  c=text; bn=n;
                  while (*text && *text!=OneCharLex[0] && *text!=OneCharLex[1] && *text!=OneCharLex[2] && *text!=OneCharLex[3]
                        && *text!=OneCharLex[4] && *text!=OneCharLex[5] && ((unsigned char)*text)>32 && *text!='/') { text++; n++; }
                  if (opt.CompareKeywords(String(c,n-bn),opt.trueconst)) list->Add(new Lexeme(lexTrue,bn,n-bn));
                  else if (opt.CompareKeywords(String(c,n-bn),opt.falseconst)) list->Add(new Lexeme(lexFalse,bn,n-bn));
                  else if (opt.CompareKeywords(String(c,n-bn),opt.elsekeyword)) list->Add(new Lexeme(lexElse,bn,n-bn));
                  else list->Add(new Lexeme(lexIdent,bn,n-bn,String(c,n-bn)));
                  continue;
                }
                text++; n++;
        }
        list->Add(new Lexeme(lexEnd, 0, 0));
}

void ParsedString::Clear()
{
        for(int i=0; i<list->Count; i++) delete (Lexeme*)list->List[i];
        list->Clear();
}

/*static char ltype[]="(),=-;ISETF*";
void ParsedString::DumpToMemo(TMemo* memo) //DEBUG
{
        memo->Lines->Clear();
        for(int i=0; i<list->Count; i++)
        {       memo->Lines->Add(String("(")+(((Lexeme*)list->List[i])->start)+","+(((Lexeme*)list->List[i])->lenght)+") "+
                        ltype[((Lexeme*)list->List[i])->type]+(((Lexeme*)list->List[i])->text));
        }
        Application->MessageBoxA("Strike a key when ready","READY",MB_OK);
}*/

ProlanfError::operator String()
{
        if (dict) return dict->name+": "+message;
        else return message;
}

ProlanfErrors::ProlanfErrors()
{       list=new TList;
}

ProlanfErrors::~ProlanfErrors()
{
        Clear();
        delete list;
}

void ProlanfErrors::Error(TProlanfDict* dict, int start, int lenght, const String& s)
{
        if (dict) list->Add(new ProlanfError(dict, start, lenght, s));
        else if (ConsoleForm) ConsoleForm->Memo->Lines->Add(s);
}

void ProlanfErrors::Clear()
{       for(int i=0; i<list->Count; i++)
                delete (ProlanfError*)list->List[i];
        list->Clear();
}

void ProlanfErrors::DeleteDict(TProlanfDict* dict)
{
        for(int i=0; i<list->Count; i++)
                if (((ProlanfError*)list->List[i])->dict==dict) ((ProlanfError*)list->List[i])->dict=NULL;
}

ProlanfFunction::ProlanfFunction()
{
        body=new TStringList;
        starthead=0; lenghthead=0;
        startbody=0; lenghtbody=0;
        dict=NULL; value=NULL;
}

ProlanfFunction::~ProlanfFunction()
{
        delete body;
        delete value;
}

ProlanfProg::ProlanfProg()
{
        Functions=new TList;
        run=NULL;
        opt.trueconst="��";
        opt.falseconst="���";
        opt.elsekeyword="�����";
        opt.CaseSensKeywords=false;
        opt.CaseSensStrings=false;
        opt.CaseSensNames=false;
        opt.AllowDoubleQuotes=true;
        opt.maxnesting=1000;
        opt.maxstring=256;
        rtopt.enterswitch=true;
        rtopt.condswitch=true;
        rtopt.switchvalue=true;
        rtopt.entercall=true;
        rtopt.argvalue=true;
        rtopt.bodycall=true;
        rtopt.funcvalue=true;
        rtopt.constvalue=true;
        rtopt.basecall=true;
}

ProlanfProg::~ProlanfProg()
{
        ClearFunctions();
        delete Functions;
}

void ProlanfProg::CompileDict(TProlanfDict* dict, ProlanfErrors* err)
{
        ParsedString parsed;
        ProlanfFunction* f;
        Lexeme **start, **startbody;
        ProlanfStruct* struc;
        parsed.Parse(dict->Memo->Lines,opt);
//        parsed.DumpToMemo(::Functions->Memo);     //DEBUG
        BuildInfo binfo(parsed.Tokens(), this, dict, err);
        while(binfo.Tokens[0]->type!=lexEnd)
        {       if (binfo.Tokens[0]->type>lexEnd) break;      //DEBUG
                if (binfo.Tokens[1]->type!=lexEnd && binfo.Tokens[2]->type!=lexEnd)
                if (binfo.Tokens[0]->type==lexIdent && binfo.Tokens[1]->type==lexOpBr)
                {       start=binfo.Tokens;
                        binfo.Tokens+=2;
                        binfo.arg->Clear();
                        if (binfo.Tokens[0]->type==lexIdent)
                        while(binfo.Tokens[0]->type==lexIdent)
                        {       binfo.arg->Append(binfo.Tokens[0]->text);
                                if (binfo.Tokens[1]->type!=lexComma || binfo.Tokens[2]->type!=lexIdent)
                                {       binfo.Tokens++; break; }
                                binfo.Tokens+=2;
                        }
                        if (binfo.Tokens[0]->type!=lexClBr || binfo.Tokens[1]->type!=lexEqu
                                || binfo.Tokens[2]->type!=lexEnd)
                        {       binfo.Tokens+=2;
                                f=FindFunction(start[0]->text);
                                if (f)
                                {       if (f->value)
                                        {       err->Error(dict,start[0]->start,start[0]->lenght,String("������� '")+start[0]->text+"' ��� ����������");
                                                NextDefine(binfo.Tokens);
                                                continue;
                                        }
                                } else
                                {       f=new ProlanfFunction;
                                        f->argc=binfo.arg->Count;
                                }
                                f->dict=NULL;
                                f->name=start[0]->text;
                                if (f->argc!=binfo.arg->Count)
                                {       err->Error(dict,start[0]->start,start[0]->lenght,String("������� '")+start[0]->text+"'���������� � ������ ������ ����������");
                                        NextDefine(binfo.Tokens);
                                        delete struc;
                                        continue;
                                }
                                AddFunction(f);
                                startbody=binfo.Tokens;
                                struc=BuildStruct(binfo);
                                if (struc)
                                {       if (binfo.Tokens[0]->type!=lexSemic)
                                        {       err->Error(dict,binfo.Tokens[0]->start,binfo.Tokens[0]->lenght,"��������� ����� � ������� ;");
                                                delete struc;
                                        } else
                                        {
                                                f->dict=dict;
                                                f->value=struc;
                                                f->starthead=start[0]->start;
                                                f->lenghthead=startbody[-2]->start-start[0]->start+startbody[-2]->lenght;
                                                f->head=String(dict->Memo->Lines->GetText()+f->starthead,f->lenghthead);
                                                f->startbody=startbody[0]->start;
                                                f->lenghtbody=binfo.Tokens[0]->start-startbody[0]->start+binfo.Tokens[0]->lenght;
                                                f->body->Append(String(dict->Memo->Lines->GetText()+f->startbody,f->lenghtbody));
                                                binfo.Tokens++;
                                                AddFunction(f); f=NULL;
                                                continue;
                                        }
                                }
                                NextDefine(binfo.Tokens);
                                continue;
                        }
                }
                err->Error(dict,binfo.Tokens[0]->start,binfo.Tokens[0]->lenght,"������ ����������� �������");
                NextDefine(binfo.Tokens);
        }
//        DumpToMemo(::Functions->Memo);  //DEBUG
}
/*
void ProlanfProg::DumpToMemo(TMemo* memo)
{
        ProlanfFunction** f=(ProlanfFunction**)Functions->List;
        memo->Lines->Clear();
        for(int i=0; i<Functions->Count; i++)
        {       memo->Lines->Add(f[i]->name+f[i]->argc+(f[i]->dict ? f[i]->dict->name : String(" NULL "))+(f[i]->value ? "Defined" : "NOT DEF"));
        }
        Application->MessageBoxA("Strike a key when ready","READY",MB_OK);
}*/

void ProlanfProg::NextDefine(Lexeme**& t)
{       while(t[0]->type!=lexSemic && t[0]->type!=lexEnd) t++;
        if (t[0]->type==lexSemic) t++;
}

ProlanfStruct* BuildStruct(BuildInfo& info)
{
        switch(info.Tokens[0]->type)
        { case lexOpBr: return (new ProlanfSwitch)->Build(info);
          case lexClBr: info.err->Error(info.dict,info.Tokens[0]->start,info.Tokens[0]->lenght,
                "������ ����������� ������");
                return NULL;
          case lexComma: info.err->Error(info.dict,info.Tokens[0]->start,info.Tokens[0]->lenght,
                "������ �������");
                return NULL;
          case lexDash: info.err->Error(info.dict,info.Tokens[0]->start,info.Tokens[0]->lenght,
                "������ ����");
                return NULL;
          case lexSemic: case lexEnd:
                info.err->Error(info.dict,info.Tokens[0]->start,info.Tokens[0]->lenght,
                "��������� ���������");
                return NULL;
          case lexStr: case lexElse: case lexTrue: case lexFalse:
                return (new ProlanfConst)->Build(info);
          case lexIdent: if (info.Tokens[1]->type!=lexOpBr) return (new ProlanfArg)->Build(info);
          return (new ProlanfCall)->Build(info);
          default: info.err->Error(info.dict,info.Tokens[0]->start,info.Tokens[0]->lenght,
                "���������� ������ - ������������ �������� �������");   //DEBUG
                return NULL;
        }
}

ProlanfStruct* ProlanfSwitch::Build(BuildInfo& info)
{
        TList* sw=new TList;
        ProlanfStruct* s;
        info.Tokens++;
        select=NULL;
        selectnum=0;
        while(1)
        {       s=BuildStruct(info);
                if (!s) break;
                sw->Add(s);
                if (info.Tokens[0]->type!=lexDash)
                {       info.err->Error(info.dict,info.Tokens[0]->start,info.Tokens[0]->lenght,"��������� ���� -");
                        break;
                }
                info.Tokens++;
                s=BuildStruct(info);
                if (!s) break;
                sw->Add(s);
                if (info.Tokens[0]->type==lexClBr)
                {       info.Tokens++;
                        selectnum=sw->Count;
                        select=new ProlanfStruct *[selectnum];
                        for(int i=0; i<selectnum; i++)
                                select[i]=(ProlanfStruct*)sw->List[i];
                        delete sw;
                        return this;
                } else if (info.Tokens[0]->type!=lexComma)
                {       info.err->Error(info.dict,info.Tokens[0]->start,info.Tokens[0]->lenght,"��������� ������� , ��� ����������� ������ )");
                        break;
                }
                info.Tokens++;
        }
        for(int i=0; i<sw->Count; i++)
                delete (ProlanfStruct*)sw->List[i];
        delete sw;
        delete this;
        return NULL;
}

ProlanfStruct* ProlanfConst::Build(BuildInfo& info)
{
        constant.refer=true;
        switch(info.Tokens[0]->type)
        { case lexStr:
                if (info.Tokens[0]->text.Length() > info.prog->opt.maxstring)
                {       info.err->Error(info.dict,info.Tokens[0]->start,info.Tokens[0]->lenght,"����� ���������� ��������� ��������� ���������� ��������");
                        delete this;
                        return NULL;
                }
                constant.text=new String(info.Tokens[0]->text);
                constant.refer=false;
                break;
          case lexTrue: case lexElse:
                constant.text=&info.prog->opt.trueconst;
                constant.refer=true;
                break;
          case lexFalse:
                constant.text=&info.prog->opt.falseconst;
                constant.refer=true;
        }
        info.Tokens++;
        return this;
}

ProlanfStruct* ProlanfArg::Build(BuildInfo& info)
{
        argno=info.arg->IndexOf(info.Tokens[0]->text);
        if (argno==-1)
        {       info.err->Error(info.dict,info.Tokens[0]->start,info.Tokens[0]->lenght,String("�������������� ������������� '")+info.Tokens[0]->text+"'");
                delete this;
                return NULL;
        }
        info.Tokens++;
        return this;
}

ProlanfStruct* ProlanfCall::Build(BuildInfo& info)
{
        TList* argv=new TList;
        ProlanfStruct* s;
        ProlanfFunction* f;
        function=NULL;
        args=NULL;
        Lexeme** start=info.Tokens;
        info.Tokens+=2;
        while(info.Tokens[0]->type!=lexClBr)
        {       s=BuildStruct(info);
                if (!s) break;
                argv->Add(s);
                if (info.Tokens[0]->type==lexClBr) break;
                if (info.Tokens[0]->type!=lexComma)
                {       info.err->Error(info.dict,info.Tokens[0]->start,info.Tokens[0]->lenght,"��������� ������� , ��� ����������� ������ )");
                        s=NULL;
                        break;
                }
                info.Tokens++;
        }
        if (info.Tokens[0]->type==lexClBr && s)
        {       info.Tokens++;
                f=info.prog->FindFunction(start[0]->text);
                if (!f)
                {       if (!info.dict)
                        {       info.err->Error(NULL,start[0]->start,start[0]->lenght,String("������� '")+start[0]->text+"' �� ����������");
                                goto failconstr;
                        }
                        f=new ProlanfFunction;
                        f->name=start[0]->text;
                        f->argc=argv->Count;
                        f->dict=NULL;
                        f->value=NULL;
                        info.prog->AddFunction(f);
                }
                if (f->argc!=argv->Count)
                        info.err->Error(info.dict,start[0]->start,start[0]->lenght,String("�������� ����� ���������� ��� ������ ������� '")+start[0]->text+"'");
                else
                {       args=new ProlanfStruct *[f->argc];
                        for(int i=0; i<f->argc; i++)
                                args[i]=(ProlanfStruct*)argv->List[i];
                        function=f;
                        delete argv;
                        return this;
                }
        }
failconstr:
        for(int i=0; i<argv->Count; i++)
                delete (ProlanfStruct*)argv->List[i];
        delete argv;
        delete this;
        return NULL;
}

ProlanfSwitch::~ProlanfSwitch()
{
        for(int i=0; i<selectnum; i++)
                delete select[i];
        delete[] select;
}

ProlanfConst::~ProlanfConst()
{
        constant.Destroy();
}

ProlanfCall::~ProlanfCall()
{
        if (function)
        for(int i=0; i<function->argc; i++)
                delete args[i];
        delete[] args;
}

void ProlanfProg::ClearFunctions()
{
        if (IsExecuting())       //DEBUG
        {       Application->MessageBox("���������� ������� ������� - ������� �������", "������ ���������", MB_OK | MB_ICONERROR);
                return;
        }
        for(int i=0; i<Functions->Count; i++)
        {       delete ((ProlanfFunction*)Functions->List[i])->value;
                ((ProlanfFunction*)Functions->List[i])->value=NULL;
        }
        for(int i=0; i<Functions->Count; i++)
                delete (ProlanfFunction*)Functions->List[i];
        Functions->Clear();
}

static char *BFName[5]={ "�����?", "������?", "������", "������", "����������" };
static int BFargc[5]= { 1, 2, 1, 1, 2 };

void ProlanfProg::AddBaseFunctions()
{
        ProlanfFunction *f;
        for(int i=0; i<5; i++)
        {       f=new ProlanfFunction;
                f->name=BFName[i];
                f->argc=BFargc[i];
                f->starthead=0;
                f->lenghthead=0;
                switch(i)
                { case 0: f->value=new ProlanfVoid;     break;
                  case 1: f->value=new ProlanfCharEqu;  break;
                  case 2: f->value=new ProlanfLastChar; break;
                  case 3: f->value=new ProlanfInitStr;  break;
                  case 4: f->value=new ProlanfCharCat;
                }
                Functions->Add(f);
        }
}

ProlanfFunction* ProlanfProg::FindFunction(const String& name)
{
        for(int i=0; i<Functions->Count; i++)
                if (opt.CompareNames(((ProlanfFunction*)Functions->List[i])->name, name))
                        return (ProlanfFunction*)Functions->List[i];
        return NULL;
}

void ProlanfProg::AddFunction(ProlanfFunction* f)
{
        int i;
        for(i=0; i<Functions->Count; i++)
                if ((ProlanfFunction*)Functions->List[i]==f)
                        Functions->Delete(i);
        i=0;
        while(i<Functions->Count && ((ProlanfFunction*)Functions->List[i])->dict==NULL &&
                ((ProlanfFunction*)Functions->List[i])->value!=NULL && ((ProlanfFunction*)Functions->List[i])->lenghthead==0) i++;
        while(i<Functions->Count && ((ProlanfFunction*)Functions->List[i])->dict==NULL &&
                ((ProlanfFunction*)Functions->List[i])->value==NULL) i++;
        if (f->value==NULL)
        {       Functions->Insert(i,f);
                return;
        }
        while(i<Functions->Count && ((ProlanfFunction*)Functions->List[i])->dict!=NULL &&
                ((ProlanfFunction*)Functions->List[i])->dict!=f->dict) i++;
        while(i<Functions->Count && ((ProlanfFunction*)Functions->List[i])->dict!=NULL &&
                ((ProlanfFunction*)Functions->List[i])->dict==f->dict) i++;
        Functions->Insert(i,f);
}

void ProlanfProg::DeleteDict(TProlanfDict* dict)
{
        ProlanfFunction* f;
        int i=0, begin, delpos, end;
        while(i<Functions->Count && ((ProlanfFunction*)Functions->List[i])->dict==NULL &&
                ((ProlanfFunction*)Functions->List[i])->value!=NULL && ((ProlanfFunction*)Functions->List[i])->lenghthead==0) i++;
        while(i<Functions->Count && ((ProlanfFunction*)Functions->List[i])->dict==NULL &&
                ((ProlanfFunction*)Functions->List[i])->value==NULL) i++;
        begin=i;
        while(i<Functions->Count && ((ProlanfFunction*)Functions->List[i])->dict!=NULL &&
                ((ProlanfFunction*)Functions->List[i])->dict!=dict) i++;
        delpos=i;
        while(i<Functions->Count && ((ProlanfFunction*)Functions->List[i])->value!=NULL) i++;
        end=i;
        while(delpos<Functions->Count && ((ProlanfFunction*)Functions->List[delpos])->dict==dict)
        {       f=(ProlanfFunction*)Functions->List[delpos];
                f->dict=NULL;
                Functions->Delete(delpos);
                if (f->value)
                        Functions->Insert(end-1,f);
                else
                        Functions->Insert(begin++,f);
        }
}

void ProlanfSwitch::Evaluate(ProlanfRuntime* rt)
{
        rt->nesting++;
        if (rt->nesting > rt->maxnesting)
        {       rt->err=reNesting;
                rt->errorstruct=this;
                return;
        }
        if (!rt->fastrun && rt->rtopt->enterswitch)
        {       rt->DebugMessage("���� � ����",this,0);
                if (rt->WaitCommand()) return;
                if (rt->command==rcUpLevel)
                {       rt->fastrun=true;
                        rt->frunstruct=this;
                }
        }
        for(int i=0; i<selectnum; i+=2)
        {       if (!rt->fastrun && rt->rtopt->condswitch)
                {       rt->DebugMessage(String("�������� ������� ")+(i/2+1), this, 1);
                        if (rt->WaitCommand()) return;
                        switch(rt->command)
                        { case rcTraceInto:
                                select[i]->Evaluate(rt);
                                break;
                          case rcStepOver:
                                rt->fastrun=true;
                                select[i]->Evaluate(rt);
                                rt->fastrun=false;
                                break;
                          case rcUpLevel:
                                rt->frunstruct=this;
                                rt->fastrun=true;
                                select[i]->Evaluate(rt);
                                break;
                          case rcRun:
                                rt->fastrun=true;
                                rt->frunstruct=NULL;
                                select[i]->Evaluate(rt);
                        }
                        rt->DismissMessage(this, 1);
                } else select[i]->Evaluate(rt);
                if (rt->terminated || rt->err!=reOk) return;
                if (rt->value.text==&rt->opt->trueconst)
                {       rt->value.Destroy();
                        select[i+1]->Evaluate(rt);
                        if (rt->terminated || rt->err!=reOk) return;
                        rt->DismissMessage(this);
                        if (!rt->fastrun && rt->rtopt->switchvalue)
                        {       rt->DebugMessage(String("�������� ����� - ")+rt->value.StringValue(*rt->opt,20),this,0);
                                if (rt->WaitCommand())
                                {       rt->value.Destroy();
                                        return;
                                }
                                rt->DismissMessage(this);
                        }
                        if (rt->fastrun && rt->frunstruct==this) rt->fastrun=false;
                        rt->nesting--;
                        return;
                }
                if (rt->value.text!=&rt->opt->falseconst)
                {       rt->value.Destroy();
                        rt->err=reType;
                        rt->errorstruct=select[i];
                        return;
                }
                rt->value.Destroy();
        }
        rt->err=reSwitch;
        rt->errorstruct=this;
}

void ProlanfConst::Evaluate(ProlanfRuntime* rt)
{
        if (!rt->fastrun && rt->rtopt->constvalue)
        {       rt->DebugMessage(String("�������� ��������� - ")+constant.StringValue(*rt->opt,20), this, 0);
                if (rt->WaitCommand()) return;
                if (!rt->fastrun) rt->DismissMessage(this);
        }
        rt->value.refer=true;
        rt->value.text=constant.text;
}

void ProlanfArg::Evaluate(ProlanfRuntime* rt)
{
        rt->value.refer=true;
        rt->value.text=rt->arg[argno].text;
}

void ProlanfCall::Evaluate(ProlanfRuntime* rt)
{
        ProlanfValue* argv;
        int i;
        rt->nesting++;
        if (rt->nesting > rt->maxnesting)
        {       rt->err=reNesting;
                rt->errorstruct=this;
                return;
        }
        if (!function->value)
        {       rt->err=reUndefCall;
                rt->errorstruct=this;
                return;
        }
        if (!rt->fastrun && rt->rtopt->entercall)
        {       rt->DebugMessage(String("����� ������� '")+function->name+"'",this,0);
        }
        argv=new ProlanfValue[function->argc];
        for(i=0; i<function->argc; i++)
        {       if (!rt->fastrun && rt->rtopt->argvalue)
                {       rt->DebugMessage(String("���������� ��������� ")+i,this,1);
                        if (rt->WaitCommand()) break;
                        switch(rt->command)
                        { case rcTraceInto:
                                function->value->Evaluate(rt);
                                break;
                          case rcStepOver:
                                rt->fastrun=true;
                                args[i]->Evaluate(rt);
                                rt->fastrun=false;
                                break;
                          case rcUpLevel:
                                rt->frunstruct=this;
                                rt->fastrun=true;
                                args[i]->Evaluate(rt);
                                break;
                          case rcRun:
                                rt->frunstruct=NULL;
                                rt->fastrun=true;
                                args[i]->Evaluate(rt);
                        }
                } else args[i]->Evaluate(rt);
                if (rt->terminated || rt->err!=reOk) { i++; break; }
                argv[i]=rt->value;
                if (!rt->fastrun) rt->DismissMessage(this,1);
        }
        if (rt->terminated || rt->err!=reOk)
        {       int j=i;
                for(int i=0; i<j; i++)
                        rt->arg[i].Destroy();
                return;
        }
        ProlanfValue* lastarg=rt->arg;
        rt->arg=argv;
        if (!rt->fastrun && rt->rtopt->bodycall)
        {       String message="(";
                for (int i=0; i<function->argc; i++)
                        message+=rt->arg[i].StringValue(*rt->opt,20)+ i==function->argc-1 ? ")'": ",";
                rt->DebugMessage(String("����� ���� ������� '")+function->name+message,this,1);
                if (!rt->WaitCommand())
                switch(rt->command)
                { case rcTraceInto:
                        function->value->Evaluate(rt);
                        break;
                  case rcStepOver:
                        rt->fastrun=true;
                        function->value->Evaluate(rt);
                        rt->fastrun=false;
                        break;
                  case rcUpLevel:
                        rt->frunstruct=this;
                        rt->fastrun=true;
                        function->value->Evaluate(rt);
                        break;
                  case rcRun:
                        rt->frunstruct=NULL;
                        rt->fastrun=true;
                        function->value->Evaluate(rt);
                }
                rt->DismissMessage(this, 1);
        } else function->value->Evaluate(rt);
        rt->arg=lastarg;
        if (rt->terminated || rt->err!=reOk)
        {       for(i=0; i<function->argc; i++) argv[i].Destroy();
                if (!rt->terminated && !rt->errorstruct) rt->errorstruct=this;
                return;
        }
        for(i=0; i<function->argc; i++)
                if (rt->value.text!=argv[i].text || !rt->value.refer || argv[i].refer)
                        argv[i].Destroy();
        if (!rt->fastrun && rt->rtopt->funcvalue)
        {       rt->DebugMessage(String("������������ �������� '")+rt->value.StringValue(*rt->opt,20)+"'",this,1);
                if (rt->WaitCommand()) { rt->value.Destroy(); return; }
        }
        if (rt->fastrun && rt->frunstruct==this) rt->fastrun=false;
        rt->DismissMessage(this);
        rt->nesting--;
}

void ProlanfVoid::Evaluate(ProlanfRuntime* rt)
{
        if (rt->arg[0].text==&rt->opt->trueconst || rt->arg[0].text==&rt->opt->falseconst)
        {       rt->err=reType;
                return;
        }
        rt->value.refer=true;
        if (rt->arg[0].text->Length()==0)
                rt->value.text=&rt->opt->trueconst;
        else    rt->value.text=&rt->opt->falseconst;
        if (!rt->fastrun && rt->rtopt->basecall)
        {       rt->DebugMessage(String("�������� ������� ������� '�����?' - ")+rt->value.StringValue(*rt->opt,20),this,0);
                if (rt->WaitCommand()) { rt->value.Destroy(); return; }
                if (!rt->fastrun) rt->DismissMessage(this);
        }
}

void ProlanfCharEqu::Evaluate(ProlanfRuntime* rt)
{
        if (rt->arg[0].text==&rt->opt->trueconst || rt->arg[0].text==&rt->opt->falseconst ||
                rt->arg[1].text==&rt->opt->trueconst || rt->arg[1].text==&rt->opt->falseconst )
        {       rt->err=reType;
                return;
        }
        if (rt->arg[0].text->Length()!=1 || rt->arg[1].text->Length()!=1)
        {       rt->err=reInvalidString;
                return;
        }
        rt->value.refer=true;
        if (rt->opt->CompareStrings(*rt->arg[0].text,*rt->arg[1].text))
                rt->value.text=&rt->opt->trueconst;
        else    rt->value.text=&rt->opt->falseconst;
        if (!rt->fastrun && rt->rtopt->basecall)
        {       rt->DebugMessage(String("�������� ������� ������� '������?' - ")+rt->value.StringValue(*rt->opt,20),this,0);
                if (rt->WaitCommand()) { rt->value.Destroy(); return; }
                if (!rt->fastrun) rt->DismissMessage(this);
        }
}

void ProlanfLastChar::Evaluate(ProlanfRuntime* rt)
{
        if (rt->arg[0].text==&rt->opt->trueconst || rt->arg[0].text==&rt->opt->falseconst)
        {       rt->err=reType;
                return;
        }
        if (rt->arg[0].text->Length()==0)
        {       rt->err=reInvalidString;
                return;
        }
        rt->value.refer=false;
        rt->value.text=new String(rt->arg[0].text->c_str()+rt->arg[0].text->Length()-1,1);
        if (!rt->fastrun && rt->rtopt->basecall)
        {       rt->DebugMessage(String("�������� ������� ������� '������' - ")+rt->value.StringValue(*rt->opt,20),this,0);
                if (rt->WaitCommand()) { rt->value.Destroy(); return; }
                if (!rt->fastrun) rt->DismissMessage(this);
        }
}

void ProlanfInitStr::Evaluate(ProlanfRuntime* rt)
{
        if (rt->arg[0].text==&rt->opt->trueconst || rt->arg[0].text==&rt->opt->falseconst)
        {       rt->err=reType;
                return;
        }
        if (rt->arg[0].text->Length()==0)
        {       rt->err=reInvalidString;
                return;
        }
        rt->value.refer=false;
        rt->value.text=new String(rt->arg[0].text->c_str(),rt->arg[0].text->Length()-1);
        if (!rt->fastrun && rt->rtopt->basecall)
        {       rt->DebugMessage(String("�������� ������� ������� '������' - ")+rt->value.StringValue(*rt->opt,20),this,0);
                if (rt->WaitCommand()) { rt->value.Destroy(); return; }
                if (!rt->fastrun) rt->DismissMessage(this);
        }
}

void ProlanfCharCat::Evaluate(ProlanfRuntime* rt)
{
        if (rt->arg[0].text==&rt->opt->trueconst || rt->arg[0].text==&rt->opt->falseconst ||
                rt->arg[1].text==&rt->opt->trueconst || rt->arg[1].text==&rt->opt->falseconst )
        {       rt->err=reType;
                return;
        }
        if (rt->arg[1].text->Length()!=1)
        {       rt->err=reInvalidString;
                return;
        }
        if (rt->arg[0].text->Length()+1 > rt->maxstring)
        {       rt->err=reStrOverflow;
                return;
        }
        rt->value.refer=false;
        rt->value.text=new String(*(rt->arg[0].text));
        *rt->value.text+=*rt->arg[1].text;
        if (!rt->fastrun && rt->rtopt->basecall)
        {       rt->DebugMessage(String("�������� ������� ������� '����������' - ")+rt->value.StringValue(*rt->opt,20),this,0);
                if (rt->WaitCommand()) { rt->value.Destroy(); return; }
                if (!rt->fastrun) rt->DismissMessage(this);
        }
}

void ProlanfProg::ExecuteLine(String& line, ProlanfErrors* err)
{
        ProlanfStruct* query;
        if (IsExecuting())
        {       Application->MessageBoxA("���������� ��������� ������ - ������� �������","������ � ���������",MB_OK | MB_ICONERROR);
                return;
        }
        ParsedString parsed;
        parsed.Parse(line,opt);
        BuildInfo binfo(parsed.Tokens(), this, NULL, err);
        query=BuildStruct(binfo);
        if (query)
        {       InitThread();
                if (!run)
                {       delete query;
                        return;
                }
                run->query=query;
                run->Resume();
        }
}

void ProlanfProg::InitThread()
{
        if (IsExecuting()) return;
        run=new ProlanfRuntime(true);
        if (!run)                               //DEBUG
        {       Application->MessageBoxA("������ ��� �������� ����","���� �� �������",MB_OK | MB_ICONERROR);
                return;
        }
        run->opt=&opt;
        run->rtopt=&rtopt;
        run->nesting=0;
        run->maxnesting=opt.maxnesting;
        run->maxstring=opt.maxstring;
        run->err=reOk;
        run->errorstruct=NULL;
        run->errorfunction=NULL;
        run->arg=NULL;
        run->FreeOnTerminate=false;
        run->fastrun=false;
}

bool ProlanfProg::IsExecuting()
{
        if (!run) return false;
        if (run->finished)
        {       run->WaitFor();
                delete run;
                run=NULL;
                return false;
        }
        return true;
}

bool ProlanfProg::IsWaiting()
{
        if (!IsExecuting()) return false;
        return run->command==rcNone && !run->terminated;
}

void ProlanfProg::StepOver()
{
        if (!IsExecuting() || run->command!=rcNone) return;
        run->command=rcStepOver;
}

void ProlanfProg::TraceInto()
{
        if (!IsExecuting() || run->command!=rcNone) return;
        run->command=rcTraceInto;
}

void ProlanfProg::UpLevel()
{
        if (!IsExecuting() || run->command!=rcNone) return;
        run->command=rcUpLevel;
}

void ProlanfProg::Run()
{
        if (!IsExecuting() || run->command!=rcNone) return;
        run->command=rcRun;
}

void ProlanfProg::Abort()
{
        if (!IsExecuting()) return;
        run->terminated=true;
        run->WaitFor();
        delete run;
        run=NULL;
}
