//---------------------------------------------------------------------------

#ifndef InterpretH
#define InterpretH

#include <system.hpp>
#include <Classes.hpp>

#include "Dict.h"
#include "Runtime.h"
//---------------------------------------------------------------------------

enum LexemeType { lexOpBr, lexClBr, lexComma, lexEqu, lexDash, lexSemic, lexIdent,
        lexStr, lexElse, lexTrue, lexFalse, lexEnd };

class Lexeme
{
public:
	Lexeme(LexemeType t, int s, int l): type(t), start(s), lenght(l) {}
	Lexeme(LexemeType t, int s, int l, const String& str): type(t), start(s), lenght(l), text(str) {}
	int start;
	int lenght;
	LexemeType type;
	String text;
};

class ParsedString
{
	TList* list;
	void Parse(char* text, ProlanfOpt& opt);
static char OneCharLex[];
static LexemeType Correspond[];
public:
	ParsedString();
	void Parse(const String& s, ProlanfOpt& opt);
	void Parse(TStrings* s, ProlanfOpt& opt);
//        void DumpToMemo(TMemo* memo);   //DEBUG
	void Clear();
	~ParsedString();
	int Count();
	Lexeme** Tokens();
};

class ProlanfError
{
public:
	ProlanfError(TProlanfDict* d, int s, int l, const String& m);
	TProlanfDict *dict;
	int start, lenght;
	String message;
	operator String();
};

class ProlanfErrors
{
	TList* list;
public:
        ProlanfErrors();
        ~ProlanfErrors();
	void Error(TProlanfDict* dict, int start, int lenght, const String& s);
	void Clear();
        void DeleteDict(TProlanfDict* dict);
        ProlanfError** List();
        int Count();
};

class ProlanfProg;

class BuildInfo
{
public:
        BuildInfo(Lexeme** t, ProlanfProg* p, TProlanfDict* d, ProlanfErrors* e);
        ~BuildInfo();
        Lexeme** Tokens;
        ProlanfProg* prog;
        TProlanfDict* dict;
        TStringList* arg;
        ProlanfErrors* err;
};

ProlanfStruct* BuildStruct(BuildInfo& info);

class ProlanfProg
{
	TList* Functions;
	ProlanfRuntime* run;
        void NextDefine(Lexeme**& t);
public:
        ProlanfOpt opt;
        RuntimeOpt rtopt;
	ProlanfProg();
	~ProlanfProg();
        ProlanfFunction** List();
        int Count();
	void CompileDict(TProlanfDict* dict, ProlanfErrors* err);
	void ClearFunctions();
        void AddBaseFunctions();
	ProlanfFunction* FindFunction(const String& name);
	void AddFunction(ProlanfFunction* f);
        void DeleteDict(TProlanfDict* dict);
        void InitThread();
	void ExecuteLine(String& line, ProlanfErrors* err);
        bool IsExecuting();
        bool IsWaiting();
	void StepOver();
	void TraceInto();
	void UpLevel();
	void Run();
	void Abort();
//        void DumpToMemo(TMemo* memo);   //DEBUG
};

class ProlanfSwitch : public ProlanfStruct
{
	ProlanfStruct** select;
	int selectnum;
public:
        ~ProlanfSwitch();
	void Evaluate(ProlanfRuntime* rt);
	ProlanfStruct* Build(BuildInfo& info);
};

class ProlanfConst : public ProlanfStruct
{
	ProlanfValue constant;
public:
        ~ProlanfConst();
	void Evaluate(ProlanfRuntime* rt);
	ProlanfStruct* Build(BuildInfo& info);
};
class ProlanfArg : public ProlanfStruct
{
	int argno;
public:
	void Evaluate(ProlanfRuntime* rt);
	ProlanfStruct* Build(BuildInfo& info);
};

class ProlanfCall : public ProlanfStruct
{
	ProlanfStruct** args;
	ProlanfFunction* function;
public:
        ~ProlanfCall();
	void Evaluate(ProlanfRuntime* rt);
	ProlanfStruct* Build(BuildInfo& info);
};

class ProlanfVoid : public ProlanfStruct
{
public:
        void Evaluate(ProlanfRuntime* rt);
};

class ProlanfCharEqu : public ProlanfStruct
{
public:
        void Evaluate(ProlanfRuntime* rt);
};

class ProlanfLastChar : public ProlanfStruct
{
public:
        void Evaluate(ProlanfRuntime* rt);
};

class ProlanfInitStr : public ProlanfStruct
{
public:
        void Evaluate(ProlanfRuntime* rt);
};

class ProlanfCharCat : public ProlanfStruct
{
public:
        void Evaluate(ProlanfRuntime* rt);
};

//---------------------------------------------------------------------------

inline void ParsedString::Parse(const String& s, ProlanfOpt& opt) { Parse(s.c_str(),opt); }
inline void ParsedString::Parse(TStrings* s, ProlanfOpt& opt) { Parse(s->GetText(),opt); }
inline ProlanfError** ProlanfErrors::List() { return (ProlanfError**)list->List; }
inline ProlanfError::ProlanfError(TProlanfDict* d, int s, int l, const String& m):
        dict(d), start(s), lenght(l), message(m) {}
inline int ProlanfErrors::Count() { return list->Count; }
inline ProlanfFunction** ProlanfProg::List() { return (ProlanfFunction**)Functions->List; }
inline int ProlanfProg::Count() { return Functions->Count; }
inline BuildInfo::BuildInfo(Lexeme** t, ProlanfProg* p, TProlanfDict* d, ProlanfErrors* e):
        Tokens(t), prog(p), dict(d), err(e), arg(new TStringList) {}
inline BuildInfo::~BuildInfo() { delete arg; }
inline int ParsedString::Count() { return list->Count-1; }
inline Lexeme** ParsedString::Tokens() { return (Lexeme**)list->List; }

#endif
