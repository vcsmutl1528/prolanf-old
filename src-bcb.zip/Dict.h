
#ifndef DictH
#define DictH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TProlanfDict : public TForm
{
__published:	// IDE-managed Components
        TMemo *Memo;
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall FormActivate(TObject *Sender);
        void __fastcall FormDeactivate(TObject *Sender);
private:	// User declarations
public:		// User declarations
        bool HasName;
        String name;
        String FileName;
        bool Save();
        bool SaveAs();
        bool SaveOne();
        bool AskSave();
        void Open(String& filename);
        __fastcall TProlanfDict(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TProlanfDict *ProlanfDict;
//---------------------------------------------------------------------------
#endif
