//---------------------------------------------------------------------------

#ifndef BreakPointsH
#define BreakPointsH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "Runtime.h"
//---------------------------------------------------------------------------
class TBrPointsForm : public TForm
{
__published:	// IDE-managed Components
        TGroupBox *BoxSwitch;
        TCheckBox *enterswitch;
        TCheckBox *condswitch;
        TCheckBox *switchvalue;
        TGroupBox *GroupBox2;
        TCheckBox *entercall;
        TCheckBox *argvalue;
        TCheckBox *bodycall;
        TCheckBox *funcvalue;
        TCheckBox *constvalue;
        TCheckBox *basecall;
        TButton *BOk;
        TButton *BCancel;
        void __fastcall BOkClick(TObject *Sender);
        void __fastcall BCancelClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TBrPointsForm(TComponent* Owner);
        void ReadRuntimeOpt(RuntimeOpt& opt);
        void SetRuntimeOpt(RuntimeOpt& opt);
};
//---------------------------------------------------------------------------
extern PACKAGE TBrPointsForm *BrPointsForm;
//---------------------------------------------------------------------------
#endif
