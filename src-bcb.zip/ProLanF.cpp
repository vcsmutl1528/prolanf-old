//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("MainForm.cpp", ProlanfForm);
USEFORM("Dict.cpp", ProlanfDict);
USEFORM("Console.cpp", ConsoleForm);
USEFORM("FuncForm.cpp", Functions);
USEFORM("Debug.cpp", DebugForm);
USEFORM("Options.cpp", OptionsForm);
USEFORM("Message.cpp", MessageForm);
USEFORM("BreakPoints.cpp", BrPointsForm);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TProlanfForm), &ProlanfForm);
                 Application->CreateForm(__classid(TOptionsForm), &OptionsForm);
                 Application->CreateForm(__classid(TBrPointsForm), &BrPointsForm);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        catch (...)
        {
                 try
                 {
                         throw Exception("");
                 }
                 catch (Exception &exception)
                 {
                         Application->ShowException(&exception);
                 }
        }
        return 0;
}
//---------------------------------------------------------------------------
