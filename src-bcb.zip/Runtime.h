//---------------------------------------------------------------------------

#ifndef RuntimeH
#define RuntimeH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include "Dict.h"
//---------------------------------------------------------------------------
class ProlanfRuntime;

class ProlanfOpt
{
public:
	String trueconst;
	String falseconst;
	String elsekeyword;
	bool CaseSensKeywords;
	bool CaseSensStrings;
	bool CaseSensNames;
	bool AllowDoubleQuotes;
        int maxstring;
        int maxnesting;
	bool CompareKeywords(const String& a, const String& b);
	bool CompareNames(const String& a, const String& b);
	bool CompareStrings(const String& a, const String& b);
};

class RuntimeOpt
{
public:
        bool enterswitch;
        bool condswitch;
        bool switchvalue;
        bool entercall;
        bool argvalue;
        bool bodycall;
        bool funcvalue;
        bool constvalue;
        bool basecall;
};

class ProlanfStruct
{
public:
	int start, lenght;
        ProlanfStruct();
	virtual ~ProlanfStruct();
	virtual void Evaluate(ProlanfRuntime* rt)=0;
};

class DebugMsg
{
public:
        DebugMsg(ProlanfStruct* s, int t);
        ProlanfStruct* struc;
        int tag;
};

class ProlanfDebug
{
        TList* messages;
public:
        ProlanfDebug();
        ~ProlanfDebug();
        void DebugMessage(String& message, ProlanfStruct* struc, int tag);
        void DismissMessage(ProlanfStruct* struc, int tag);
        void DismissMessage(ProlanfStruct* struc);
        void DismissAll();
};

class ProlanfValue
{
public:
	String *text;
	bool refer;
	void Destroy();
        String StringValue(ProlanfOpt& opt, int maxlen=0);
};

class ProlanfFunction
{
public:
        ProlanfFunction();
        ~ProlanfFunction();
	String name;
	int argc;
        String head;
	int starthead, lenghthead;
        TStrings* body;
	int startbody, lenghtbody;
	TProlanfDict* dict;
	ProlanfStruct* value;
};

enum RuntimeCommand { rcNone, rcStepOver, rcTraceInto, rcUpLevel, rcRun };
enum RuntimeError { reOk, reSwitch, reType, reUndefCall, reInvalidString,
                reStrOverflow, reNesting, reUserAbort };

class ProlanfRuntime : public TThread
{
private:
        String message;
        ProlanfStruct* struc;
        int tag;
        void __fastcall SynDebugMessage();
        void __fastcall SynDismissMessage();
        void __fastcall SynDismissMessageA();
        void __fastcall SynDismissAll();
        void __fastcall ConsoleMessage();
protected:
        void __fastcall Execute();
public:
        __fastcall ProlanfRuntime(bool CreateSuspended);
        ProlanfStruct* query;
        ProlanfOpt* opt;
        RuntimeOpt* rtopt;
        ProlanfDebug dbg;
        ProlanfValue* arg;
        ProlanfValue value;
        int nesting;
        int maxnesting;
        int maxstring;
        bool fastrun;
        bool terminated;
        bool finished;
        RuntimeCommand command;
        RuntimeError err;
        ProlanfStruct* frunstruct;
        ProlanfStruct* errorstruct;
        ProlanfFunction* errorfunction;
        bool WaitCommand();
        void DebugMessage(String& m, ProlanfStruct* s, int t);
        void DismissMessage(ProlanfStruct* s, int t);
        void DismissMessage(ProlanfStruct* s);
};

inline DebugMsg::DebugMsg(ProlanfStruct* s, int t): struc(s), tag(t) {}
inline ProlanfStruct::ProlanfStruct(): start(0), lenght(0) {}
inline void ProlanfRuntime::DebugMessage(String& m, ProlanfStruct* s, int t)
{ message=m; struc=s; tag=t; Synchronize(SynDebugMessage); }
inline void ProlanfRuntime::DismissMessage(ProlanfStruct* s, int t)
{ struc=s; tag=t; Synchronize(SynDismissMessage); }
inline void ProlanfRuntime::DismissMessage(ProlanfStruct* s)
{ struc=s; Synchronize(SynDismissMessageA); }
//---------------------------------------------------------------------------
#endif
