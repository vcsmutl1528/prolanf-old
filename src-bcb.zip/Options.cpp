//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Options.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TOptionsForm *OptionsForm;
//---------------------------------------------------------------------------
__fastcall TOptionsForm::TOptionsForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void TOptionsForm::ReadProlanfOpt(ProlanfOpt& opt)
{
        CheckBox1->Checked=!opt.CaseSensKeywords;
        CheckBox2->Checked=!opt.CaseSensStrings;
        CheckBox3->Checked=!opt.CaseSensNames;
        Edit1->Text=opt.trueconst;
        Edit2->Text=opt.falseconst;
        Edit3->Text=opt.elsekeyword;
        Edit4->Text=opt.maxnesting;
        CheckBox4->Checked=opt.AllowDoubleQuotes;
        Edit5->Text=opt.maxstring;
}

void TOptionsForm::SetProlanfOpt(ProlanfOpt& opt)
{
        opt.CaseSensKeywords=!CheckBox1->Checked;
        opt.CaseSensStrings=!CheckBox2->Checked;
        opt.CaseSensNames=!CheckBox3->Checked;
        opt.trueconst=Edit1->Text;
        opt.falseconst=Edit2->Text;
        opt.elsekeyword=Edit3->Text;
        opt.maxnesting=Edit4->Text.ToInt();
        opt.AllowDoubleQuotes=CheckBox4->Checked;
        opt.maxstring=Edit5->Text.ToInt();
}

void __fastcall TOptionsForm::Button1Click(TObject *Sender)
{
        ModalResult=mrOk;        
}
//---------------------------------------------------------------------------

void __fastcall TOptionsForm::Button2Click(TObject *Sender)
{
        ModalResult=mrCancel;
}
//---------------------------------------------------------------------------

