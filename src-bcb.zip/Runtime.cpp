//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Runtime.h"
#include "Console.h"
#include "Debug.h"
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Important: Methods and properties of objects in VCL can only be
//   used in a method called using Synchronize, for example:
//
//      Synchronize(UpdateCaption);
//
//   where UpdateCaption could look like:
//
//      void __fastcall ProlanfRuntime::UpdateCaption()
//      {
//        Form1->Caption = "Updated in a thread";
//      }
//---------------------------------------------------------------------------

__fastcall ProlanfRuntime::ProlanfRuntime(bool CreateSuspended)
        : TThread(CreateSuspended)
{
        finished=false;
}
//---------------------------------------------------------------------------
void __fastcall ProlanfRuntime::Execute()
{
        while (!terminated && command==rcNone);
        if (command==rcRun) fastrun=true;
        query->Evaluate(this);
        Synchronize(SynDismissAll);
        switch(err)
        { case reOk: message=value.StringValue(*opt,opt->maxstring);
                value.Destroy(); break;
          case reSwitch: message="�� ����������� �� ���� ������� � �����";
                break;
          case reType: message="�������� ���"; break;
          case reUndefCall: message="������� ������ ������������� �������"; break;
          case reInvalidString: message="������������ �������� ������"; break;
          case reStrOverflow: message="����� ������ ��������� ���������� ��������"; break;
          case reNesting: message="������� ������� ��� ����������� ��������"; break;
          case reUserAbort: message="���������� ������� ���� ��������";
        }
        Synchronize(ConsoleMessage);
        delete query;
        finished=true;
}
//---------------------------------------------------------------------------
bool ProlanfRuntime::WaitCommand()
{
        command=rcNone;
        while(command==rcNone && !terminated);
        return terminated;
}

void __fastcall ProlanfRuntime::SynDebugMessage()
{
        dbg.DebugMessage(message, struc, tag);
}

void __fastcall ProlanfRuntime::SynDismissMessage()
{
        dbg.DismissMessage(struc, tag);
}

void __fastcall ProlanfRuntime::SynDismissMessageA()
{
        dbg.DismissMessage(struc);
}

void __fastcall ProlanfRuntime::SynDismissAll()
{
        dbg.DismissAll();
}

void __fastcall ProlanfRuntime::ConsoleMessage()
{
        ConsoleForm->Memo->Lines->Add(message);
}

void ProlanfValue::Destroy()
{       if (!refer) delete text;
}

String ProlanfValue::StringValue(ProlanfOpt& opt, int maxlen)
{
        if (text==&opt.trueconst || text==&opt.falseconst)
                return *text;
        if (text->Length()>maxlen)
                return String("'")+String(text->c_str(),maxlen)+"..'";
        return String("'")+*text+"'";
}

ProlanfStruct::~ProlanfStruct()
{
}

ProlanfDebug::ProlanfDebug()
{
        messages=new TList;
}

ProlanfDebug::~ProlanfDebug()
{
        DismissAll();
        delete messages;
}

void ProlanfDebug::DebugMessage(String& message, ProlanfStruct* struc, int tag)
{
        if (DebugForm) DebugForm->ListBox->Items->Add(message);
        messages->Add(new DebugMsg(struc,tag));
}

void ProlanfDebug::DismissMessage(ProlanfStruct* struc, int tag)
{
        int i=messages->Count-1;
        while(i>=0 && ((DebugMsg*)messages->List[i])->struc==struc
                && ((DebugMsg*)messages->List[i])->tag>=tag)
        {       if (DebugForm) DebugForm->ListBox->Items->Delete(i);
                delete (DebugMsg*)messages->List[i];
                messages->Delete(i);
        }
}

void ProlanfDebug::DismissMessage(ProlanfStruct* struc)
{
        int i=messages->Count-1;
        while(i>=0 && ((DebugMsg*)messages->List[i])->struc==struc)
        {       if (DebugForm) DebugForm->ListBox->Items->Delete(i);
                delete (DebugMsg*)messages->List[i];
                messages->Delete(i);
        }
}

void ProlanfDebug::DismissAll()
{
        for(int i=0; i<messages->Count; i++)
                delete (DebugMsg*)messages->List[i];
        messages->Clear();
        if (DebugForm) DebugForm->ListBox->Items->Clear();
}

