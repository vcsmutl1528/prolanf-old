//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Console.h"
#include "MainForm.h"
#include "Message.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TConsoleForm *ConsoleForm;
//---------------------------------------------------------------------------
__fastcall TConsoleForm::TConsoleForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TConsoleForm::FormResize(TObject *Sender)
{
        Memo->Top=0;
        Memo->Left=0;
        Memo->Width=Width-10;
        Memo->Height=Height-54;
        Edit->Top=Height-52;
        Edit->Left=0;
        Edit->Width=Width-10;
}
//---------------------------------------------------------------------------

void __fastcall TConsoleForm::FormClose(TObject *Sender,
      TCloseAction &Action)
{
        ProlanfForm->ViewConsole->Checked=false;
        Action=caFree;
}
//---------------------------------------------------------------------------

void __fastcall TConsoleForm::FormCreate(TObject *Sender)
{
        FormResize(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TConsoleForm::EditKeyPress(TObject *Sender, char &Key)
{
        if (Key==13)
        {       Memo->Lines->Add(String("> ")+Edit->Text);
                ProlanfForm->prog->ExecuteLine(Edit->Text,ProlanfForm->err);
                Edit->Text="";
                if (MessageForm) MessageForm->UpdateMessages();
                ProlanfForm->prog->Run();
                Key=0;
        }
}
//---------------------------------------------------------------------------

