//---------------------------------------------------------------------------

#ifndef MessageH
#define MessageH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "Interpret.h"
//---------------------------------------------------------------------------
class TMessageForm : public TForm
{
__published:	// IDE-managed Components
        TListBox *ListBox;
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall ListBoxDblClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TMessageForm(TComponent* Owner);
        void UpdateMessages();
};
//---------------------------------------------------------------------------
extern PACKAGE TMessageForm *MessageForm;
//---------------------------------------------------------------------------
#endif
