//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainForm.h"
#include "FuncForm.h"
#include "Message.h"
#include "Console.h"
#include "Debug.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TProlanfForm *ProlanfForm;
//---------------------------------------------------------------------------
__fastcall TProlanfForm::TProlanfForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::NCascadeClick(TObject *Sender)
{
        Cascade();        
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::NHorzClick(TObject *Sender)
{
        TileMode = tbHorizontal;
        Tile();
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::NVertClick(TObject *Sender)
{
        TileMode = tbVertical;
        Tile();
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::NArrangeClick(TObject *Sender)
{
        ArrangeIcons();
}
//---------------------------------------------------------------------------


void __fastcall TProlanfForm::BreakPointsExecute(TObject *Sender)
{
        BrPointsForm->ReadRuntimeOpt(prog->rtopt);
        if (BrPointsForm->ShowModal()==mrOk)
                BrPointsForm->SetRuntimeOpt(prog->rtopt);
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::PropertiesExecute(TObject *Sender)
{
        OptionsForm->ReadProlanfOpt(prog->opt);
        if (OptionsForm->ShowModal()==mrOk)
                OptionsForm->SetProlanfOpt(prog->opt);
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::NewDictExecute(TObject *Sender)
{
        TProlanfDict* newdict=new TProlanfDict(this);
        if (!newdict) return;
        newdict->name=FindUniqueName();
        newdict->Caption=newdict->name;
        newdict->Show();
        AddDictExecute(newdict);
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::FormCreate(TObject *Sender)
{
        Dicts=new TList;
        err=new ProlanfErrors;
        debug=new ProlanfDebug;
        prog=new ProlanfProg;
        DictSelected=false;
        ConsoleForm=NULL;
        DebugForm=NULL;
        MessageForm=NULL;
        Functions=NULL;
        SaveDict->Enabled=false;
        SaveDictAs->Enabled=false;
        SaveAll->Enabled=false;
        prog->AddBaseFunctions();
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::FormDestroy(TObject *Sender)
{
        delete Dicts;
        delete err;
        delete debug;
        delete prog;
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::N8Click(TObject *Sender)
{
        Close();
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::ViewFunctionsExecute(TObject *Sender)
{
        if (ViewFunctions->Checked)
        {       delete Functions;
                Functions=NULL;
                ViewFunctions->Checked=false;
        } else
        {       Functions=new TFunctions(this);
                ViewFunctions->Checked=true;
        }
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::ViewMessagesExecute(TObject *Sender)
{
        if (ViewMessages->Checked)
        {       delete MessageForm;
                MessageForm=NULL;
                ViewMessages->Checked=false;
        } else
        {       MessageForm=new TMessageForm(this);
                ViewMessages->Checked=true;
        }
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::ViewConsoleExecute(TObject *Sender)
{
        if (ViewConsole->Checked)
        {       delete ConsoleForm;
                ConsoleForm=NULL;
                ViewConsole->Checked=false;
        } else
        {       ConsoleForm=new TConsoleForm(this);
                ViewConsole->Checked=true;
        }
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::ViewDebugExecute(TObject *Sender)
{
        if (ViewDebug->Checked)
        {       delete DebugForm;
                DebugForm=NULL;
                ViewDebug->Checked=false;
        } else
        {       DebugForm=new TDebugForm(this);
                ViewDebug->Checked=true;
        }
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::OpenDictExecute(TObject *Sender)
{
        if (OpenDialog->Execute())
        {       TProlanfDict* newdict=new TProlanfDict(this);
                if (!newdict) return;
                newdict->Open(OpenDialog->FileName);
                newdict->Show();
                AddDictExecute(newdict);
        }
}
//---------------------------------------------------------------------------
AnsiString __fastcall TProlanfForm::FindUniqueName()
{
        int ind=1, i;
        while(1)
        {       String name=String("�������")+ind;
                for(i=0; i<Dicts->Count; i++)
                        if (((TProlanfDict*)Dicts->List[i])->name==name) break;
                if (i==Dicts->Count) return name;
                ind++;
        }
}

void __fastcall TProlanfForm::CloseDictExecute(TProlanfDict* dict)
{
        Dicts->Remove(dict);
        prog->DeleteDict(dict);
        err->DeleteDict(dict);
        if (MessageForm) MessageForm->UpdateMessages();
        if (Functions) Functions->UpdateFunctions(); 
        if (Dicts->Count==0) SaveAll->Enabled=false;
}

void __fastcall TProlanfForm::AddDictExecute(TProlanfDict* dict)
{
        Dicts->Add(dict);
        if (Dicts->Count!=0) SaveAll->Enabled=true;
}

void __fastcall TProlanfForm::SaveDictExecute(TObject *Sender)
{
        if (DictSelected) ((TProlanfDict*)ActiveMDIChild)->Save();
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::SaveDictAsExecute(TObject *Sender)
{
        if (DictSelected) ((TProlanfDict*)ActiveMDIChild)->SaveAs();
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::SaveAllExecute(TObject *Sender)
{
        for(int i=0; i<Dicts->Count; i++)
                if (((TProlanfDict*)Dicts->List[i])->SaveOne()) break;
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::FormClose(TObject *Sender,
      TCloseAction &Action)
{
        int i;
        for(i=0; i<Dicts->Count; i++) if(((TProlanfDict*)Dicts->List[i])->AskSave()) break;
        if (i==Dicts->Count)
                Action=caFree;
        else    Action=caNone;
}
//---------------------------------------------------------------------------
void __fastcall TProlanfForm::CompileAllExecute(TObject *Sender)
{
        err->Clear();
        prog->ClearFunctions();
        prog->AddBaseFunctions();
        for(int i=0; i<Dicts->Count; i++)
                prog->CompileDict((TProlanfDict*)Dicts->List[i],err);
        if (MessageForm) MessageForm->UpdateMessages();
        if (Functions) Functions->UpdateFunctions();
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::AbortExecute(TObject *Sender)
{
        prog->Abort();
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::TraceIntoExecute(TObject *Sender)
{
        prog->TraceInto();        
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::StepOverExecute(TObject *Sender)
{
        prog->StepOver();        
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::UpLevelExecute(TObject *Sender)
{
        prog->UpLevel();        
}
//---------------------------------------------------------------------------

void __fastcall TProlanfForm::RunExecute(TObject *Sender)
{
        prog->Run();
}
//---------------------------------------------------------------------------

