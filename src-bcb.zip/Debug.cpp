//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Debug.h"
#include "MainForm.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TDebugForm *DebugForm;
//---------------------------------------------------------------------------
__fastcall TDebugForm::TDebugForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TDebugForm::FormClose(TObject *Sender,
      TCloseAction &Action)
{
        ProlanfForm->ViewDebug->Checked=false;
        ProlanfForm->TraceInto->Enabled=false;
        ProlanfForm->StepOver->Enabled=false;
        ProlanfForm->UpLevel->Enabled=false;
        Action=caFree;
}
//---------------------------------------------------------------------------


void __fastcall TDebugForm::FormCreate(TObject *Sender)
{
        ProlanfForm->TraceInto->Enabled=true;
        ProlanfForm->StepOver->Enabled=true;
        ProlanfForm->UpLevel->Enabled=true;
}
//---------------------------------------------------------------------------

