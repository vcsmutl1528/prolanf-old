//---------------------------------------------------------------------------

#ifndef MainFormH
#define MainFormH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ActnList.hpp>
#include <ComCtrls.hpp>
#include <ImgList.hpp>
#include <Menus.hpp>
#include <ToolWin.hpp>
#include <Dialogs.hpp>

#include "Interpret.h"
#include "BreakPoints.h"
#include "Interpret.h"
#include "Options.h"
#include "FuncForm.h"
//---------------------------------------------------------------------------
class TProlanfForm : public TForm
{
__published:	// IDE-managed Components
        TMainMenu *MainMenu1;
        TActionList *ActionList1;
        TImageList *ImageList1;
        TMenuItem *MFile;
        TMenuItem *N2;
        TMenuItem *N3;
        TMenuItem *N4;
        TMenuItem *N5;
        TMenuItem *N6;
        TMenuItem *N7;
        TMenuItem *N8;
        TMenuItem *MView;
        TMenuItem *N10;
        TMenuItem *N11;
        TMenuItem *N12;
        TMenuItem *N13;
        TMenuItem *N14;
        TMenuItem *MDataBase;
        TMenuItem *N16;
        TMenuItem *N17;
        TMenuItem *N18;
        TToolBar *ToolBar1;
        TToolButton *ToolButton1;
        TToolButton *ToolButton2;
        TToolButton *ToolButton3;
        TToolButton *ToolButton4;
        TToolButton *ToolButton5;
        TToolButton *ToolButton6;
        TToolButton *ToolButton7;
        TToolButton *ToolButton8;
        TToolButton *ToolButton9;
        TToolButton *ToolButton10;
        TToolButton *ToolButton11;
        TToolButton *ToolButton12;
        TToolButton *ToolButton13;
        TToolButton *ToolButton14;
        TToolButton *ToolButton15;
        TToolButton *ToolButton16;
        TToolButton *ToolButton17;
        TToolButton *ToolButton18;
        TToolButton *ToolButton19;
        TToolButton *ToolButton20;
        TToolButton *ToolButton21;
        TToolButton *ToolButton22;
        TToolButton *ToolButton23;
        TMenuItem *MExecute;
        TMenuItem *N20;
        TMenuItem *N21;
        TMenuItem *N22;
        TMenuItem *N23;
        TMenuItem *N24;
        TMenuItem *N25;
        TMenuItem *N26;
        TMenuItem *MWindow;
        TMenuItem *NNew;
        TMenuItem *NCascade;
        TMenuItem *NHorz;
        TMenuItem *NVert;
        TMenuItem *NArrange;
        TToolButton *ToolButton24;
        TToolButton *ToolButton25;
        TMenuItem *N1;
        TMenuItem *N9;
        TAction *NewDict;
        TAction *OpenDict;
        TAction *SaveDict;
        TAction *SaveDictAs;
        TAction *SaveAll;
        TAction *ViewFunctions;
        TAction *ViewMessages;
        TAction *ViewConsole;
        TAction *ViewDebug;
        TAction *ViewDBase;
        TAction *CompileAll;
        TAction *Abort;
        TAction *Properties;
        TAction *TraceInto;
        TAction *StepOver;
        TAction *UpLevel;
        TAction *Run;
        TAction *BreakPoints;
        TAction *BDAdd;
        TAction *DBOpen;
        TAction *DBDelete;
        TOpenDialog *OpenDialog;
        TSaveDialog *SaveDialog;
        void __fastcall NCascadeClick(TObject *Sender);
        void __fastcall NHorzClick(TObject *Sender);
        void __fastcall NVertClick(TObject *Sender);
        void __fastcall NArrangeClick(TObject *Sender);
        void __fastcall BreakPointsExecute(TObject *Sender);
        void __fastcall PropertiesExecute(TObject *Sender);
        void __fastcall NewDictExecute(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall FormDestroy(TObject *Sender);
        void __fastcall N8Click(TObject *Sender);
        void __fastcall ViewFunctionsExecute(TObject *Sender);
        void __fastcall ViewMessagesExecute(TObject *Sender);
        void __fastcall ViewConsoleExecute(TObject *Sender);
        void __fastcall ViewDebugExecute(TObject *Sender);
        void __fastcall OpenDictExecute(TObject *Sender);
        void __fastcall SaveDictExecute(TObject *Sender);
        void __fastcall SaveDictAsExecute(TObject *Sender);
        void __fastcall SaveAllExecute(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall CompileAllExecute(TObject *Sender);
        void __fastcall AbortExecute(TObject *Sender);
        void __fastcall TraceIntoExecute(TObject *Sender);
        void __fastcall StepOverExecute(TObject *Sender);
        void __fastcall UpLevelExecute(TObject *Sender);
        void __fastcall RunExecute(TObject *Sender);
private:	// User declarations
        TList* Dicts;
        ProlanfDebug* debug;
        AnsiString __fastcall FindUniqueName();
public:		// User declarations
        __fastcall TProlanfForm(TComponent* Owner);
        bool DictSelected;
        ProlanfErrors* err;
        ProlanfProg* prog;
        void __fastcall AddDictExecute(TProlanfDict* dict);
        void __fastcall CloseDictExecute(TProlanfDict* dict);
};
//---------------------------------------------------------------------------
extern PACKAGE TProlanfForm *ProlanfForm;
//---------------------------------------------------------------------------
#endif
