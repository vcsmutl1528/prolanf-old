//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "FuncForm.h"
#include "MainForm.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFunctions *Functions;
//---------------------------------------------------------------------------
__fastcall TFunctions::TFunctions(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TFunctions::FormResize(TObject *Sender)
{
        Edit->Left=Splitter->Left+5;
        Edit->Width=Width-Splitter->Left-14;
        Edit->Top=0;
        Memo->Top=28;
        Memo->Width=Width-Splitter->Left-14;
        Memo->Left=Splitter->Left+5;
        Memo->Height=Height-55;
}
//---------------------------------------------------------------------------

void __fastcall TFunctions::FormClose(TObject *Sender,
      TCloseAction &Action)
{
        ProlanfForm->ViewFunctions->Checked=false;
        Action=caFree;
}
//---------------------------------------------------------------------------

void __fastcall TFunctions::FormCreate(TObject *Sender)
{
        UpdateFunctions();
}
//---------------------------------------------------------------------------
void __fastcall TFunctions::UpdateFunctions()
{
        TTreeNode* tbase=NULL, *curr;
        TProlanfDict* ndict;
        ProlanfFunction** f=ProlanfForm->prog->List();
        int count=ProlanfForm->prog->Count(), i=0;
        TreeView->Items->Clear();
        if (i<count && f[i]->dict==NULL && f[i]->value!=NULL && f[i]->lenghthead==0)
        {       tbase=TreeView->Items->AddObject(tbase,"������� �������",NULL);
                tbase->ImageIndex=0; tbase->SelectedIndex=0;
        }
        while(i<count && f[i]->dict==NULL && f[i]->value!=NULL && f[i]->lenghthead==0)
        {       curr=TreeView->Items->AddChildObject(tbase,f[i]->name,NULL);
                curr->ImageIndex=1; curr->SelectedIndex=1;
                i++;
        }
        if (i<count && f[i]->dict==NULL && f[i]->value==NULL)
        {       tbase=TreeView->Items->AddObject(tbase,"�������������",NULL);
                tbase->ImageIndex=3; tbase->SelectedIndex=3;
        }
        while(i<count && f[i]->dict==NULL && f[i]->value==NULL)
        {       curr=TreeView->Items->AddChildObject(tbase,f[i]->name,NULL);
                curr->ImageIndex=3; curr->SelectedIndex=3;
                i++;
        }
        while (i<count && f[i]->dict!=NULL)
        {       ndict=f[i]->dict;
                tbase=TreeView->Items->AddObject(tbase,ndict->name,NULL);
                tbase->ImageIndex=4; tbase->SelectedIndex=4;
                while(i<count && f[i]->dict==ndict)
                {       curr=TreeView->Items->AddChildObject(tbase,f[i]->name,f[i]);
                        curr->ImageIndex= f[i]->value ? 2 : 3;
                        curr->SelectedIndex= f[i]->value ? 2 : 3;
                        i++;
                }
        }
        if (i<count && f[i]->dict==NULL)
        {       tbase=TreeView->Items->AddObject(tbase,"��������",NULL);
                tbase->ImageIndex=5; tbase->SelectedIndex=5;
        }
        while(i<count && f[i]->dict==NULL)
        {       curr=TreeView->Items->AddChildObject(tbase,f[i]->name,f[i]);
                curr->ImageIndex= f[i]->value ? 2 : 3;
                curr->SelectedIndex= f[i]->value ? 2 : 3;
                i++;
        }
        Edit->Text="";
        Memo->Lines->Clear();
}

void __fastcall TFunctions::TreeViewClick(TObject *Sender)
{
        if (TreeView->Selected && TreeView->Selected->Data!=NULL)
        {       Edit->Text=((ProlanfFunction*)TreeView->Selected->Data)->head;
                Memo->Lines->Assign(((ProlanfFunction*)TreeView->Selected->Data)->body);
        } else
        {       Edit->Text="";
                Memo->Lines->Clear();
        }
}
//---------------------------------------------------------------------------

void __fastcall TFunctions::TreeViewDblClick(TObject *Sender)
{
        ProlanfFunction* f;
        if (TreeView->Selected && TreeView->Selected->Data!=NULL &&
                ((ProlanfFunction*)TreeView->Selected->Data)->dict!=NULL)
        {       f=(ProlanfFunction*)TreeView->Selected->Data;
                f->dict->Memo->SelStart=f->startbody;
                f->dict->Memo->SelLength=f->lenghtbody;
                f->dict->FormActivate(Sender);
                f->dict->BringToFront();
        }
}
//---------------------------------------------------------------------------

