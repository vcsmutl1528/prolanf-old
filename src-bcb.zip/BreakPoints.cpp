//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "BreakPoints.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TBrPointsForm *BrPointsForm;
//---------------------------------------------------------------------------
__fastcall TBrPointsForm::TBrPointsForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void TBrPointsForm::ReadRuntimeOpt(RuntimeOpt& opt)
{
        enterswitch->Checked=opt.enterswitch;
        condswitch->Checked=opt.condswitch;
        switchvalue->Checked=opt.switchvalue;
        entercall->Checked=opt.entercall;
        argvalue->Checked=opt.argvalue;
        bodycall->Checked=opt.bodycall;
        funcvalue->Checked=opt.funcvalue;
        constvalue->Checked=opt.constvalue;
        basecall->Checked=opt.basecall;
}

void TBrPointsForm::SetRuntimeOpt(RuntimeOpt& opt)
{
        opt.enterswitch=enterswitch->Checked;
        opt.condswitch=condswitch->Checked;
        opt.switchvalue=switchvalue->Checked;
        opt.entercall=entercall->Checked;
        opt.argvalue=argvalue->Checked;
        opt.bodycall=bodycall->Checked;
        opt.funcvalue=funcvalue->Checked;
        opt.constvalue=constvalue->Checked;
        opt.basecall=basecall->Checked;
}

void __fastcall TBrPointsForm::BOkClick(TObject *Sender)
{
        ModalResult=mrOk;        
}
//---------------------------------------------------------------------------

void __fastcall TBrPointsForm::BCancelClick(TObject *Sender)
{
        ModalResult=mrCancel;        
}
//---------------------------------------------------------------------------

